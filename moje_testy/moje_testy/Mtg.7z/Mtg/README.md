# mtg
Collection of data science and machine learning projects for Magic: the Gathering
